var likesThree = document.querySelector("#like3")
var likesTwo = document.querySelector("#like2")
var likesOne = document.querySelector("#like1")

function addLike (element) {
    if(element.id === "button1"){
    likesOne.innerHTML =  parseInt(likesOne.innerHTML)+1;
    } else if (element.id === "button2"){
        likesTwo.innerHTML =  parseInt(likesTwo.innerHTML)+1;
    } else {
        likesThree.innerHTML =  parseInt(likesThree.innerHTML)+1;
    }
}

function removeLike (element) {
    if(element.id === "dislike-button1"){
        likesOne.innerHTML =  parseInt(likesOne.innerHTML)-1;
        } else if (element.id === "dislike-button2"){
            likesTwo.innerHTML =  parseInt(likesTwo.innerHTML)-1;
        } else {
            likesThree.innerHTML =  parseInt(likesThree.innerHTML)-1;
        }
}